from django.apps import AppConfig


class PaylConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'payl'
