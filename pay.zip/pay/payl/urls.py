from django.urls import path
from .import views

urlpatterns = [
    path('', views.home,name='bank'),
    path('reqhandler',views.reqhandler,name='reqhandler'),]