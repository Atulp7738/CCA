from django.shortcuts import render
from django.http import HttpResponse
from urllib.request import urlopen 
import requests
import json
from Crypto.Cipher import AES
from hashlib import md5 as md5
from payl.ccavutil import *

accessCode = 'AVKT09IF91AU02TKUA' 	
workingKey ='007B20091A438561F95609C572CEF84F'



def home(request):
  return render(request,'dataFrom.html')

# Create your views here.
def index(request):
  url = "https://secure.ccavenue.com/transaction/transaction.do?command=initiatePayloadTransaction&encRequest=79827a40c80d10879c4a2bcba0e7800daf68f02c0ee8e8023ee62330085a4ad07401175da8d71e6bad05b8070765a73e7a9207738710d6414ade3a8fd729f878425769942ed4f52b25ed278f586dd6850fbdb3d5cc52daf72cb3c92e9283fce9620099a13d7bb1723199b5016e637588a13a31b080a6287a949005c80900444c21281733ea19b4e88ac6f2b1747281415d22d3627872b9f4bcaae66f18f85d5f7a9f33d13553b04839dcdfb47f15f895c9e93e8162a239ef59b0f3fc4e0489065f868b0b32c694102caa12a5e79fd58757c3bafea173d6c921be49badd3ef7f9adc0baac27f7902d00b30a2a63b95732f3865574a2434a391c62a20b05123b2eb315160c83771bcdd7eeacde75bbf7e9&access_code=AVEZ69JB03AD89ZEDA"
  response = urlopen(url) 
  data_json = json.loads(response.read()) 

  print(data_json)

  payload= data_json["data"]
  burl= data_json["bankUrl"]
  method= data_json["method"]
  
  html = '<html><body><form action='+burl+'  method='+method+' > <input type= submit></form></body></html>'

  #if (method == 'GET') :
   # r = requests.get(url = burl, data = payload)
 # else :
    #r = requests.get(url = burl, data = payload)
  
  return render(request,'bank.html',{'mtd':method,'url':burl, 'data':payload } )
  
def load(request):
  return render(request,'dataform.html')
  
def reqhandler(request):
  form= request.POST.dict()
  enc=''
  for key, value in form.items():
    enc= enc + key +'='+ value +'&'
  
  encryp=encrypt(enc, workingKey)
    
  return render (request,'ccavenue.html',{'enc':encryp,'acc':accessCode})
    # TODO: write code...

#def reqhandler(request):
  
  